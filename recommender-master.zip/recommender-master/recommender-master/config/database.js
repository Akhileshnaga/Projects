exports = module.exports = function(){
    return {
        User: "<username>",
        Password: "<password>"
    };
};
